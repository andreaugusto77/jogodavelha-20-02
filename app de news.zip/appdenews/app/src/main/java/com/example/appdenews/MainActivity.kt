package com.example.appdenews

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val center: imageview = findViewById(R.id.center)
             
        center.setOnclickListener{
            Toast.makeText(,MainActivity@this "teste", Toast.LENGTH_SHORT).show()
        }
    }
}

