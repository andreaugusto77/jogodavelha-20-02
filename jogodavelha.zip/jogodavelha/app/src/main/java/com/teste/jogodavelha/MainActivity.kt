import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.GridLayout
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.android.synthetic.main.activity_main.*


class MainActivity : AppCompatActivity() {

    private var currentPlayer = 1
    private val board = Array(3) { IntArray(3) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        initializeBoard()
    }

    private fun initializeBoard() {
        for (i in 0 until gridLayout.childCount) {
            val cell = gridLayout.getChildAt(i) as Button
            cell.setOnClickListener { onCellClick(cell) }
            board[i / 3][i % 3] = 0
        }
    }

    private fun onCellClick(cell: Button) {
        val row = GridLayout.LayoutParams(cell.layoutParams).rowSpec.indicator
        val col = GridLayout.LayoutParams(cell.layoutParams).columnSpec.indicator

        if (board[row][col] == 0) {
            board[row][col] = currentPlayer
            cell.text = if (currentPlayer == 1) "X" else "O"

            if (checkWinner()) {
                announceWinner()
            } else {
                currentPlayer = if (currentPlayer == 1) 2 else 1
            }
        }
    }

    private fun checkWinner(): Boolean {
        // Check rows, columns, and diagonals for a winner
        for (i in 0 until 3) {
            if (board[i][0] == board[i][1] && board[i][1] == board[i][2] && board[i][0] != 0) {
                return true
            }
            if (board[0][i] == board[1][i] && board[1][i] == board[2][i] && board[0][i] != 0) {
                return true
            }
        }

        if (board[0][0] == board[1][1] && board[1][1] == board[2][2] && board[0][0] != 0) {
            return true
        }

        if (board[0][2] == board[1][1] && board[1][1] == board[2][0] && board[0][2] != 0) {
            return true
        }

        return false
    }

    private fun announceWinner() {
        val winner = if (currentPlayer == 1) "O" else "X"
        val message = "Player $winner wins!"
        // You can add your own logic for what to do when a player wins
        // For example, show a dialog or reset the game
    }
}
